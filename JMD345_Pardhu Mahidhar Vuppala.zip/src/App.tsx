import React from 'react';
import logo from './logo.svg';
import './App.css';
import Home from './component/Home';
import Details from './component/Details';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

function App() {
  return (
    <div className="App">
        <BrowserRouter>
        <Routes>
        <Route path="/" element={<Home/>}></Route>
        <Route path="/Details/:id" element={<Details/>}></Route>
        </Routes>
        </BrowserRouter>
    </div>
  );
}
export default App;
