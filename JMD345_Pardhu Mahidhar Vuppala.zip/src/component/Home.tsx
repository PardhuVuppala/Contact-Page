import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './Home.css'

interface Pokemon {
    name: string;
    url: string;
}

interface ApiResponse {
    results: Pokemon[];
}

interface PokemonData {
    id: number;
    image: string;
    name: string;
}

interface Berry {
    name: string;
    url: string;
}

interface BerryApiResponse {
    results: Berry[];
}


interface Location {
    name: string,
    url:string
}
 interface LocationAPIResponse
 {
    results : Location[]
 }

 
interface Items {
    name: string,
    url:string
}
 interface ItemsAPIResponse
 {
    results : Items[]
 }

const Home = () => {
    const [pokemonData, setPokemonData] = useState<PokemonData[]>([]);
    const [berries, setBerries] = useState<Berry[]>([]);
    const [Location,setLocation] = useState<Location[]>([])
    const[Items,SetItems] = useState<Items[]>([])

    useEffect(() => {
        // Pokemon
        axios.get<ApiResponse>("https://pokeapi.co/api/v2/pokemon?offset=0&limit=40")
            .then(response => {
                const results = response.data.results;
                console.log(results);
                const pokemonList = results.map((pokemon, index) => {
                    const id = index + 1;
                    return {
                        id,
                        image: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`,
                        name: pokemon.name
                    };
                });

                setPokemonData(pokemonList);
            })
            .catch(error => {
                console.error("There was an error fetching the Pokémon data!", error);
            });
            // Berry

        axios.get<BerryApiResponse>("https://pokeapi.co/api/v2/berry?offset=0&limit=40")
            .then(response => {
                const results = response.data.results;
              //  console.log(results)
                setBerries(results);
            })
            .catch(error => {
                console.error("There was an error fetching the Berry data!", error);
            });

         // Location
         axios.get<LocationAPIResponse>("https://pokeapi.co/api/v2/location?offset=0&limit=40")
         .then(response=>
         {
            const results = response.data.results;
         // console.log(results)
            setLocation(results)
         }
         )



         //items

         axios.get<ItemsAPIResponse>("https://pokeapi.co/api/v2/item?offset=0&limit=40")
         .then(response=>
         {
            const results = response.data.results;
         // console.log(results)
            SetItems(results)
         }
         )



    }, []);

    return (
        <div className="container">
            <ul>
  <li><a href="#Pokemon">Pokemon List</a></li>
  <li><a href="#Locate">Location</a></li>
  <li><a href="#Berry" >Berry</a></li>
  <li><a href="#Items">Items</a></li>
</ul>
            <h1 className="text-center mb-4" >Pokemon List</h1>
            <div className="row" id="Pokemon">
                {pokemonData.map(pokemon => (
                    <div className="col-md-3 col-sm-6 mb-3" key={pokemon.id}>
                        <div className="card shadow-sm">
                            <img
                                src={pokemon.image}
                                className="card-img-top"
                                alt={`Image of ${pokemon.name}`}
                            />
                            <div className="card-body text-center">
                                <h5 className="card-title text-success">{pokemon.name}</h5>
                                <Link to={`/Details/${pokemon.id}`} className='btn btn-success'>View Details</Link>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            <h2 className="text-center mt-4" id="Berry">Berries</h2>
            <div className="row">
                {berries.map((berry, index) => (
                    <div className="col-md-3 col-sm-6 mb-3" key={index}>
                        <div className="card shadow-sm">
                            <div className="card-body text-center">
                                <img  src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/${berry.name}-berry.png`}></img>
                                <h5 className="card-title text-success">{berry.name}</h5>
                            </div>
                        </div>
                    </div>
                ))}
            </div>


     
            <h2 className="text-center mt-4" id="Locate" >Locations</h2>

            <div className="row" >
                {Location.map((location, index) => (
                    <div className="col-md-3 col-sm-6 mb-3" key={index}>
                        <div className="card shadow-sm">
                            <div className="card-body text-center">
                                <h5 className="card-title text-success">{location.name}</h5>
                            </div>
                        </div>
                    </div>
                ))}
            </div>






            <h2 className="text-center mt-4">Items</h2>

<div className="row" id="Items">
    {Items.map((items, index) => (
        <div className="col-md-3 col-sm-6 mb-3" key={index}>
            <div className="card shadow-sm">
                <div className="card-body text-center">
                <img  src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/${items.name}.png`}></img>
                    <h5 className="card-title text-success">{items.name}</h5>
                </div>
            </div>
        </div>
    ))}
</div>
        </div>
    );
}

export default Home;
