import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

interface PokemonStat {
    base_stat: number;
    stat: {
        name: string;
    };
}

interface PokemonType {
    slot: number;
    type: {
        name: string;
        url: string;
    };
}

interface PokemonAbility {
    ability: {
        name: string;
        url: string;
    };
}

interface PokemonDetail {
    name: string;
    image: string;
    types: PokemonType[];
    abilities: PokemonAbility[];
    stats: PokemonStat[];
}

const Details = () => {
    const { id } = useParams<{ id: string }>(); 
    const [pokemon, setPokemon] = useState<PokemonDetail | null>(null);

    useEffect(() => {
        axios.get(`https://pokeapi.co/api/v2/pokemon/${id}`)
            .then(response => {
                const data = response.data;
                console.log(data)
                setPokemon({
                    name: data.name,
                    image: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`,
                    types: data.types.map((type: any) => ({
                        slot: type.slot,
                        type: {
                            name: type.type.name,
                            url: type.type.url
                        }
                    })),
                    abilities: data.abilities.map((ability: any) => ({
                        ability: {
                            name: ability.ability.name,
                            url: ability.ability.url
                        }
                    })),
                    stats: data.stats.map((stat: any) => ({
                        base_stat: stat.base_stat,
                        stat: {
                            name: stat.stat.name
                        }
                    }))
                });
            })
            .catch(error => {
                console.error('There was an error fetching the Pokémon details!', error);
            });
    }, [id]);

    return (
        <div className="container mt-4">
            {pokemon ? (
                <div className="text-center">
                    <h1 className="mb-4 text-success">{pokemon.name}</h1>
                    <img src={pokemon.image} alt={pokemon.name} className="img-fluid mb-4" />
                    
                    <div className="row mb-4">
                        <div className="col-md-4">
                            <div className="card border-primary">
                                <div className="card-header bg-primary text-white">
                                    <h5 className="mb-0">Types</h5>
                                </div>
                                <ul className="list-group list-group-flush">
                                    {pokemon.types.map(type => (
                                        <li key={type.slot} className="list-group-item">
                                            {type.type.name}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                        
                        <div className="col-md-4">
                            <div className="card border-success">
                                <div className="card-header bg-success text-white">
                                    <h5 className="mb-0">Abilities</h5>
                                </div>
                                <ul className="list-group list-group-flush">
                                    {pokemon.abilities.map(ability => (
                                        <li key={ability.ability.name} className="list-group-item">
                                            {ability.ability.name}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                        
                        <div className="col-md-4">
                            <div className="card border-info">
                                <div className="card-header bg-info text-white">
                                    <h5 className="mb-0">Stats</h5>
                                </div>
                                <ul className="list-group list-group-flush">
                                    {pokemon.stats.map(stat => (
                                        <li key={stat.stat.name} className="list-group-item">
                                            {stat.stat.name}: {stat.base_stat}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            ) : (
             <div className="d-flex justify-content-center align-items-center min-vh-100">
             <div className="spinner-border text-success"></div>
         </div>
            )}
        </div>
    );
};

export default Details;
